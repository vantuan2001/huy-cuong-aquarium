const Fail = () => {
  return <div>Fail</div>;
};

export default Fail;
